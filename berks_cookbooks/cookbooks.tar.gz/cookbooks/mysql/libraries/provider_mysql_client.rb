require 'chef/provider'

class Chef
  class Provider
    class MysqlClient < Chef::Provider::LWRPBase
      def action_create
      end
    end
  end
end
